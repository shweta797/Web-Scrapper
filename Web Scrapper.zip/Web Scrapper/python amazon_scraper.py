import time
import json
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Initialize Selenium WebDriver
def setup_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    return driver

# Scrape Best Sellers for a Category
def scrape_category(driver, category_url, max_products=1500):
    data = []
    driver.get(category_url)
    logging.info(f"Scraping category: {category_url}")
    product_count = 0

    while product_count < max_products:
        try:
            # Wait for product elements to load
            products = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".zg-grid-general-faceout"))
            )
            logging.info(f"Found {len(products)} products on the current page.")

            for product in products:
                try:
                    # Extract product details
                    product_name = (
                        product.find_element(By.CSS_SELECTOR, ".p13n-sc-truncate")
                        .text.strip()
                        if product.find_elements(By.CSS_SELECTOR, ".p13n-sc-truncate")
                        else "N/A"
                    )
                    price = (
                        product.find_element(By.CSS_SELECTOR, ".p13n-sc-price")
                        .text.strip()
                        if product.find_elements(By.CSS_SELECTOR, ".p13n-sc-price")
                        else "N/A"
                    )
                    rating = (
                        product.find_element(By.CSS_SELECTOR, ".a-icon-alt")
                        .text.strip()
                        if product.find_elements(By.CSS_SELECTOR, ".a-icon-alt")
                        else "N/A"
                    )
                    category_name = driver.title.split(":")[0].strip()  # Extract category from page title

                    # Placeholder for additional fields
                    discount = "N/A"
                    ship_from = "N/A"
                    sold_by = "N/A"
                    description = "N/A"
                    number_bought = "N/A"
                    images = ["N/A"]  # Extend logic to fetch images if available

                    # Append data
                    data.append({
                        "Category Name": category_name,
                        "Product Name": product_name,
                        "Price": price,
                        "Discount": discount,
                        "Rating": rating,
                        "Ship From": ship_from,
                        "Sold By": sold_by,
                        "Description": description,
                        "Number Bought": number_bought,
                        "Images": images
                    })
                    product_count += 1

                    if product_count >= max_products:
                        break
                except Exception as e:
                    logging.warning(f"Error extracting product details: {e}")

            # Navigate to the next page
            try:
                next_button = driver.find_element(By.CSS_SELECTOR, ".a-pagination .a-last a")
                next_button.click()
                logging.info("Navigating to the next page.")
                time.sleep(2)  # Delay to avoid being flagged
            except:
                logging.info("No more pages available in this category.")
                break
        except Exception as e:
            logging.error(f"Error loading category page: {e}")
            break

    if not data:
        logging.warning(f"No data scraped for {category_url}. Please check the selectors and page structure.")
    return data

# Save data to JSON
def save_to_json(data, output_file="amazon_data.json"):
    with open(output_file, "w") as f:
        json.dump(data, f, indent=4)
    logging.info(f"Data saved to {output_file}")

# Main script
if __name__ == "__main__":
    # Sample category URLs
    category_urls = [
        "https://www.amazon.in/gp/bestsellers/kitchen/ref=zg_bs_nav_kitchen_0",
        "https://www.amazon.in/gp/bestsellers/shoes/ref=zg_bs_nav_shoes_0",
        "https://www.amazon.in/gp/bestsellers/computers/ref=zg_bs_nav_computers_0",
        "https://www.amazon.in/gp/bestsellers/electronics/ref=zg_bs_nav_electronics_0"
    ]

    driver = setup_driver()
    all_data = []

    try:
        for url in category_urls:
            category_data = scrape_category(driver, url, max_products=1500)
            all_data.extend(category_data)

        save_to_json(all_data)
    except Exception as e:
        logging.error(f"An error occurred: {e}")
    finally:
        driver.quit()
